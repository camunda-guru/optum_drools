package com.optum.insurance.models;

import java.util.Date;

public class CreditCard {

	private String cardNo;
	private Date expiryDate;
	private int cvvNo;
	private long credeitLimit;
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getCvvNo() {
		return cvvNo;
	}
	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}
	public long getCredeitLimit() {
		return credeitLimit;
	}
	public void setCredeitLimit(long credeitLimit) {
		this.credeitLimit = credeitLimit;
	}
	
	
	
	
}
