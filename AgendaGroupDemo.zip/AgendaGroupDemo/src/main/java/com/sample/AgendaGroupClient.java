package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.runtime.StatefulKnowledgeSession;

import com.optum.models.LoanAmount;

public class AgendaGroupClient {

    public static void main(String args[]) throws Exception {

    	KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	KieSession kSession = kContainer.newKieSession("ksession-rules");
        try {
            LoanAmount loanAmount = new LoanAmount();
            loanAmount.setBankBalance(10000);
            loanAmount.setMonthlyInstallment(8000);
            loanAmount.setAccountId("ACC013867");
            
            kSession.insert(loanAmount);
            kSession.getAgenda().getAgendaGroup("Check Balance").setFocus();
            kSession.fireAllRules();
        } finally {
        	kSession.dispose();
        }
    }

   
}