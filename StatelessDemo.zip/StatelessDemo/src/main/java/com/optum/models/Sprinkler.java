package com.optum.models;

public class Sprinkler {

	private boolean waterLine;

	public boolean isWaterLine() {
		return waterLine;
	}

	public void setWaterLine(boolean waterLine) {
		this.waterLine = waterLine;
	}
	
}
