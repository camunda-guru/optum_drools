package com.sample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.process.WorkflowProcessInstance;

public class ReusableProcess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> messages = new ArrayList<String>();
        messages.add("message 1");
        messages.add("message 2");
        messages.add("message 3");
        
        Map<String,Object> parameters = new HashMap<String, Object>();
        parameters.put("messages", messages); 
        KieServices ks = KieServices.Factory.get();
	    KieContainer kContainer = ks.getKieClasspathContainer();
    	KieSession kSession = kContainer.newKieSession("ksession-process");
        //Start the process using its id
        ProcessInstance process = kSession.startProcess("org.plugtree.training.jbpm.reusablesubprocessparent",parameters);
        
        //The process will run until there are no more nodes to execute.
        //Because this process doesn't have any wait-state, the process is
        //running from start to end
        System.out.println( process.getState());
        
        //Because the process changed the reference of messages variable, we
        //need to get it again.
        //It is a good practice to retrieve the process variables after its 
        //execution instead of use the old variables passed as parameters.
        messages = (List<String>) ((WorkflowProcessInstance)process).getVariable("messages");
        for (String message : messages) {
            System.out.println("Message = "+message);
        }

	}

}
