package com.sample;

import java.util.ArrayList;
import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.runtime.ExecutionResults;
import org.kie.api.runtime.Globals;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.command.CommandFactory;

/**
 * This is a sample class to launch a rule.
 */
public class DroolsTest {

    public static final void main(String[] args) {
        try {
            // load up the knowledge base
	        KieServices ks = KieServices.Factory.get();
    	    KieContainer kContainer = ks.getKieClasspathContainer();
        	KieSession kSession = kContainer.newKieSession("ksession-rules");
        	Globals globals = kSession.getGlobals();
    		System.out.println( globals.getGlobalKeys() );
    		List list = new ArrayList();
    		list.add("loc1");
    		list.add("loc2");
    		list.add("loc3");
    		list.add("loc4");
    		//kSession.setGlobal( "myGlobalList", list );
    		System.out.println( globals.getGlobalKeys() );
    		
    		List cmds = new ArrayList();
    		 cmds.add( CommandFactory.newSetGlobal( "customerList", list, true ) );
    	  		 ExecutionResults results = kSession.execute( CommandFactory.newBatchExecution( cmds ) );
    	          
            kSession.fireAllRules();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
