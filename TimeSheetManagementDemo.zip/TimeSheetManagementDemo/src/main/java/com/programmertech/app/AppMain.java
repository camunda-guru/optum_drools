package com.programmertech.app;

import java.io.StringReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.kie.api.KieBase;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.programmertech.model.Applicant;

public class AppMain {
	static Map<String, KieBase> kieBaseCache = null;
	static {
		kieBaseCache = new HashMap<>();
	}

	public static void main(String[] args) {

		Set<Applicant> applicants = new HashSet<>();
		applicants.add(new Applicant(1, "Raj", "25/05/1975", "M"));
		applicants.add(new Applicant(2, "Ram", "25/03/1905", "M"));
		applicants.add(new Applicant(3, "Anjali", "25/03/1993", "F"));
		applicants.add(new Applicant(4, "Rani", "01/07/1945", "F"));
		for (Applicant applicant : applicants) {
			System.out.println("*** Before Rule Execution ***");
			System.out.println(applicant.toString());
			executeStatefull(applicant);
			System.out.println("*** After Rule Execution ***");
			System.out.println(applicant.toString()+"\n");

		}

		/*for (Applicant applicant : applicants) {
			System.out.println(applicant.toString());
		}*/

	}

	public static void executeStatefull(Applicant applicant) {

		try {
			KieSession kieSession = null;
			if (kieBaseCache.get("validateApplicant") == null) {
				String content = new String(Files.readAllBytes(Paths.get("src/main/resources/rules/validateApplicant.drl")),
						Charset.forName("UTF-8"));
				System.out.println("Read New Rules set from File");
				// load up the knowledge base
				KieServices ks = KieServices.Factory.get();
				String inMemoryDrlFileName = "src/main/resources/stateFulSessionRule.drl";
				KieFileSystem kfs = ks.newKieFileSystem();
				kfs.write(inMemoryDrlFileName, ks.getResources().newReaderResource(new StringReader(content))
						.setResourceType(ResourceType.DRL));
				KieBuilder kieBuilder = ks.newKieBuilder(kfs).buildAll();
				if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
					System.out.println(kieBuilder.getResults().toString());
				}
				KieContainer kContainer = ks.newKieContainer(kieBuilder.getKieModule().getReleaseId());
				KieBaseConfiguration kbconf = ks.newKieBaseConfiguration();
				KieBase kbase = kContainer.newKieBase(kbconf);
				kieSession = kbase.newKieSession();
				System.out.println("Put rules KieBase into Custom Cache");
				kieBaseCache.put("validateApplicant", kbase);
			} else {
				System.out.println("Get existing rules KieBase from Custom Cache");
				kieSession = kieBaseCache.get("validateApplicant").newKieSession();
			}

			/*
			 * kSession.addEventListener(new DebugAgendaEventListener());
			 * kSession.addEventListener(new DebugRuleRuntimeEventListener());
			 */

			kieSession.insert(applicant);
			kieSession.fireAllRules();

			kieSession.dispose();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

}
