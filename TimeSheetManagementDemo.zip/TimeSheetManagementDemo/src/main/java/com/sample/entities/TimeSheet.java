package com.sample.entities;

public class TimeSheet {
	private int employeeHours;
	private boolean projectBudgetOK;
	private boolean duplicateTimeSheet;
	private boolean overlappingTimeSheet;
	private String payStatus;
	public int getEmployeeHours() {
		return employeeHours;
	}
	public void setEmployeeHours(int employeeHours) {
		this.employeeHours = employeeHours;
	}
	public boolean isProjectBudgetOK() {
		return projectBudgetOK;
	}
	public void setProjectBudgetOK(boolean projectBudgetOK) {
		this.projectBudgetOK = projectBudgetOK;
	}
	public boolean isDuplicateTimeSheet() {
		return duplicateTimeSheet;
	}
	public void setDuplicateTimeSheet(boolean duplicateTimeSheet) {
		this.duplicateTimeSheet = duplicateTimeSheet;
	}
	public boolean isOverlappingTimeSheet() {
		return overlappingTimeSheet;
	}
	public void setOverlappingTimeSheet(boolean overlappingTimeSheet) {
		this.overlappingTimeSheet = overlappingTimeSheet;
	}
	public String getPayStatus() {
		return payStatus;
	}
	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}
	
	
}
