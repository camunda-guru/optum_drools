package com.sample;

import java.io.File;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.kie.api.KieBase;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.io.Resource;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.sample.entities.TimeSheet;

/**
 * This is a sample class to launch a rule.
 */
public class DroolsTest {
	private static TimeSheet getValues()
	{
		TimeSheet sheet=new TimeSheet();
		sheet.setEmployeeHours(52);
		sheet.setProjectBudgetOK(false);
		sheet.setOverlappingTimeSheet(false);
		return sheet;
	}
	

	public static void fireTimeSheet()
	{
		try {
		
			
			/*	
			String content = new String(Files.readAllBytes(Paths.get("src/main/resources/rules/TimeSheetRules.drl")),
						Charset.forName("UTF-8"));
				System.out.println("Read New Rules set from File");
				// load up the knowledge base
				KieServices ks = KieServices.Factory.get();
				String inMemoryDrlFileName = "src/main/resources/rules/TimeSheetRules.drl";
				KieFileSystem kfs = ks.newKieFileSystem();
				kfs.write(inMemoryDrlFileName, ks.getResources().newReaderResource(new StringReader(content))
						.setResourceType(ResourceType.DRL));
							KieBuilder kieBuilder = ks.newKieBuilder(kfs).buildAll();
				*/
	
			KieServices ks = KieServices.Factory.get();
			KieFileSystem kfs = ks.newKieFileSystem();
			File file = new File("src/main/resources/rules/TimeSheetRules.drl");
			Resource resource = ks.getResources().newFileSystemResource(file).setResourceType(ResourceType.DRL);
			 kfs.write( resource);  
			KieBuilder kb =ks.newKieBuilder(kfs);
			
			 kb.buildAll();
			
				
				KieContainer kContainer = ks.newKieContainer(kb.getKieModule().getReleaseId());
				KieBaseConfiguration kbconf = ks.newKieBaseConfiguration();
				KieBase kbase = kContainer.newKieBase(kbconf);
				KieSession kieSession = kbase.newKieSession();
			
			

			/*
			 * kSession.addEventListener(new DebugAgendaEventListener());
			 * kSession.addEventListener(new DebugRuleRuntimeEventListener());
			 */
           TimeSheet timeSheet=getValues();
			kieSession.insert(timeSheet);
			kieSession.fireAllRules();
            System.out.println("Final TimeSheet status"+timeSheet.getPayStatus());
			kieSession.dispose();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}
	
	
    public static final void main(String[] args) {
    	fireTimeSheet();
        /*
    	try {
            // load up the knowledge base
	        KieServices ks = KieServices.Factory.get();
    	    KieContainer kContainer = ks.getKieClasspathContainer();
        	KieSession kSession = kContainer.newKieSession("ksession-rules");

            // go !
            Message message = new Message();
            message.setMessage("Hello World");
            message.setStatus(Message.HELLO);
            kSession.insert(message);
            kSession.fireAllRules();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        */
    }

    public static class Message {

        public static final int HELLO = 0;
        public static final int GOODBYE = 1;

        private String message;

        private int status;

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public int getStatus() {
            return this.status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

    }

}
