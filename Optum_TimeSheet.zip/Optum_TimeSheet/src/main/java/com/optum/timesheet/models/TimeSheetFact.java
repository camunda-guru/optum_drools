package com.optum.timesheet.models;

public class TimeSheetFact {

	private int workingHours;
	private boolean budgetOK;
	private boolean timeSheetOverlapping;
	private String paymentStatus;
	
	public boolean isBudgetOK() {
		return budgetOK;
	}
	public void setBudgetOK(boolean budgetOK) {
		this.budgetOK = budgetOK;
	}
	public boolean isTimeSheetOverlapping() {
		return timeSheetOverlapping;
	}
	public void setTimeSheetOverlapping(boolean timeSheetOverlapping) {
		this.timeSheetOverlapping = timeSheetOverlapping;
	}
	public int getWorkingHours() {
		return workingHours;
	}
	public void setWorkingHours(int workingHours) {
		this.workingHours = workingHours;
	}
	
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
}
