package com.sample;

import java.util.ArrayList;
import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.runtime.ExecutionResults;
import org.kie.api.runtime.Globals;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.command.CommandFactory;

import com.optum.timesheet.models.TimeSheetFact;

public class TimeSheetApp {
	
	private static TimeSheetFact getData()
	{
		TimeSheetFact timeSheetFact =new TimeSheetFact();
		timeSheetFact.setWorkingHours(52);
		timeSheetFact.setBudgetOK(false);
		timeSheetFact.setTimeSheetOverlapping(false);
		return timeSheetFact;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		KieServices kservices=KieServices.Factory.get();
		KieContainer container =kservices.getKieClasspathContainer();
		KieSession ksession= container.newKieSession("ksession-tsrules");
		Globals globals =  ksession.getGlobals();
		System.out.println( globals.getGlobalKeys() );
		List list = new ArrayList();
		list.add("loc1");
		list.add("loc2");
		list.add("loc3");
		list.add("loc4");
		
		System.out.println( globals.getGlobalKeys() );
		
		List cmds = new ArrayList();
		//Sets the global but also when the out parameter is true specifies that the global is added to the ExecutionResults.
		 cmds.add( CommandFactory.newSetGlobal( "customerList", list, true ) );
	  		 ExecutionResults results =  ksession.execute( CommandFactory.newBatchExecution( cmds ) );
	  		 //System.out.println(results);
		TimeSheetFact obj =getData();
		ksession.insert(obj);
		ksession.fireAllRules();
		System.out.println(obj.getPaymentStatus());
		
		
	}

}
