package com.nokia.entities;

public class Alarm {

}
