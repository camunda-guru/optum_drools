package com.optum.models;

public enum DayOfWeek {
Sun,Mon,Tue,Wed
}
