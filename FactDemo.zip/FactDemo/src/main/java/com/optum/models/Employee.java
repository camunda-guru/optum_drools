package com.optum.models;


public class Employee {
private DayOfWeek dayOff;

public DayOfWeek getDayOff() {
	return dayOff;
}

public void setDayOff(DayOfWeek dayOff) {
	this.dayOff = dayOff;
}

public Employee(DayOfWeek dayOff) {
	super();
	this.dayOff = dayOff.Mon;
}

}
