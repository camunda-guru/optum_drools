package com.sample;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.definition.type.FactType;
import org.kie.api.runtime.ExecutionResults;
import org.kie.api.runtime.Globals;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.command.CommandFactory;

/**
 * This is a sample class to launch a rule.
 */
public class DroolsTest {

    public static final void main(String[] args) {
    	// TODO Auto-generated method stub
    			KieServices ks = KieServices.Factory.get();
    		    KieContainer kContainer = ks.getKieClasspathContainer();
    	    	KieSession kSession = kContainer.newKieSession("Global-Session");
    	    	KieBase kbase=kContainer.getKieBase("TemplatesKB");
    	    	FactType factType =  kbase.getFactType("com.sample", "Address");
    	    	Object address;
				try {
					address = factType.newInstance();
					factType.set(address, "city", "Bangalore");
	    	    	factType = kbase.getFactType("com.sample", "Customer");
	    	    		Object customer = factType.newInstance();
	    	    	factType.set(customer, "name","Basu");
	    	    	factType.set(customer, "dateOfBirth",new Date(112,1,1));
	    	    	factType.set(customer, "address",address);
	    	    	kSession.insert( customer );
	    	    	//kSession.fireAllRules();

	    	    	// read attributes
	    	    	String name = (String) factType.get( customer, "name" );
	    	    	Date date  = (Date) factType.get( customer, "dateOfBirth" );
	    	        System.out.println(name);   	    	
	    	      
	    	        
	    	       
	    				kSession.fireAllRules();
	    				  //proxy instance
		    	        factType = kbase.getFactType("com.sample", "GoldenCustomer");
		    	        
		    	        System.out.println(factType.getField("balance"));
		    	       
				} catch (InstantiationException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    	    	
    }

    

}
